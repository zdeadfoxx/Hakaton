<footer class="footer">
    <div class="container">
        <div class="footer__row">
            <nav class="header__navigation">
                <div class="footer__nav">
                    <ul class=" d-flex">
                        <li class="nav-item navbar__nav-item hover">
                            <a href="{{ route('main') }}">Главная</a>
                        </li>
                      <li class="nav-item navbar__nav-item hover">
                        <a href="#">Профиль</a>
                      </li>
                      <li class="nav-item navbar__nav-item hover">
                        <a href="#">Усулги</a>
                      </li>
                    </ul>
                  </div>
                  <div class="social__row">
                    <div class="social__body">
                        <div class="vk">
                            <img src="{{ asset('img/svg/vk.svg') }}" alt="vk">
                        </div>
                        <div class="whatsapp">
                            <img src="{{ asset('img/svg/whatsapp.svg') }}" alt="what">
                        </div>
                        <div class="telelgram">
                            <img src="{{ asset('img/svg/telegram.svg') }}" alt="telegram">
                        </div>
                    </div>
                  </div>
                  <div class="copirate">
                    <img src="{{ asset('img/svg/copirate.svg') }}" alt="copi">
                    <p>ATL 2023</p>
                  </div>
            </nav>
        </div>
    </div>
</footer>
