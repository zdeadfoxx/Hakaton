<header class=" header" >
    <div class="container">
        <div class="header__row">
            <div class="header__title ">
                <a href="{{ route('main') }}">ATL</a>
            </div>
            <nav class="header__navigation">
                <div class=" ">
                    <ul class=" d-flex">
                      <li class="nav-item navbar__nav-item hover">
                        <a href="#">Профиль</a>
                      </li>
                      <li class="nav-item navbar__nav-item ">
                        <a href="#">Усулги</a>
                      </li>
                      <li class="nav-item">

                      </li>
                    </ul>
                  </div>
            </nav>
        </div>
    </div>

</header>
